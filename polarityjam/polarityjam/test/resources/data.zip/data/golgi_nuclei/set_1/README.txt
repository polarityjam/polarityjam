missing segmentation file is on purpose. part of test routine!
